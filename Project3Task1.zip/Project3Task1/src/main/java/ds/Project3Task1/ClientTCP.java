package ds.Project3Task1;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import com.google.gson.Gson;

/**
 * This Java code file represents a TCP client for interacting with a blockchain server.
 * Users are presented with a menu of options to select from.
 * Based on the user's selection, the program constructs a request message and communicates with the server using Gson for JSON serialization.
 * The server responds with a message, which is then processed and displayed to the user.
 **/
public class ClientTCP {
    private static Socket clientSocket;
    private static final Scanner readInput = new Scanner(System.in);
    private static final RequestMessage request_message = new RequestMessage();
    private static ResponseMessage response_message = new ResponseMessage();
    private static final Gson gson = new Gson();

    public static void main(String args[]) {
        try {
            int serverPort = 7777;
            clientSocket = new Socket("localhost", serverPort);
            while(true){
                System.out.println("0. View basic blockchain status.\n" +
                        "1. Add a transaction to the blockchain.\n" +
                        "2. Verify the blockchain.\n" +
                        "3. View the blockchain.\n" +
                        "4. Corrupt the chain.\n" +
                        "5. Hide the corruption by repairing the chain.\n" +
                        "6. Exit.\n");
                int option = Integer.parseInt(readInput.nextLine());
                if (option < 0 || option > 6) {
                    System.out.println("Invalid option.");
                }else{
                request_message.setSelection(option);
                if (option == 1) {
                    System.out.println("Enter difficulty > 0");
                    int difficulty = readInput.nextInt();
                    request_message.setDifficulty(difficulty);
                    System.out.println("Enter transaction");
                    readInput.nextLine();
                    String data = readInput.nextLine();
                    request_message.setData(data);
              } else if (option == 4) {
                    System.out.println("corrupt the Blockchain");
                    System.out.println("Enter block ID of block to corrupt");
                    int index = readInput.nextInt();
                    request_message.setIndex(index);
                    System.out.println("Enter new data for block " + index);
                    readInput.nextLine();
                    String corrupt_message = readInput.nextLine();
                    request_message.setData(corrupt_message);
                } else if (option == 6) {
                    break;
                }
                try {
                    //Work Cited:https://github.com/CMU-Heinz-95702/Project-2-Client-Server
                    BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                    String data = gson.toJson(request_message);
                    out.println(data);
                    out.flush();
                    response_message = gson.fromJson(in.readLine(), ResponseMessage.class);
                } catch (IOException e) {
                    System.out.println("IO Exception:" + e.getMessage());
                }
                if (option == 0) {
                    System.out.println("Current size of chain: " + response_message.get_chain_size());
                    System.out.println("Difficulty of most recent block: " + response_message.get_difficulty());
                    System.out.println("Total difficulty for all blocks: " + response_message.get_sum_of_difficulty());
                    System.out.println("Approximate hashes per second on this machine: " + response_message.get_hash_per_second());
                    System.out.println("Expected total hashes required for the whole chain: " + response_message.getTotalHashes());
                    System.out.println("Nonce for most recent block: " + response_message.getLatestNonce());
                    System.out.println("Chain hash: " + response_message.getChainHash());
                } else if (option == 2) {
                    System.out.println("Chain verification: " + response_message.getVerification());
                    if(!(response_message.getVerification().equals("TRUE"))){
                    System.out.println(response_message.getErrorMessage());}
                } else if (option == 3) {
                    System.out.println("View the Blockchain");
                }
                    System.out.println(response_message.getResponse());
                }
            }
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException ignored) {
            }
        }
    }


}

