package ds.Project3Task1;

/**
 * A class to encapsulate the request message
 * */

//For this question, I have discussed with PW, XY for som function clarifications.
// Work Cited: Piazza

public class RequestMessage {
    private int selection;
    private int difficulty;
    private String data;
    private int index;

    /**
     * Default constructor for RequestMessage.
     */
    public RequestMessage() {
    }


    /**
     * Sets the selection value.
     *
     * @param selection The selection value to set.
     */
    public void setSelection(int selection) {

        this.selection = selection;
    }

    /**
     * Sets the difficulty value.
     *
     * @param difficulty The difficulty value to set.
     */
    public void setDifficulty(int difficulty) {

        this.difficulty = difficulty;
    }

    /**
     * Sets the data string.
     *
     * @param data The data string to set.
     */
    public void setData(String data) {

        this.data = data;
    }

    /**
     * Sets the index value.
     *
     * @param index The index value to set.
     */
    public void setIndex(int index) {

        this.index = index;
    }

    /**
     * Gets the selection value.
     *
     * @return The selection value.
     */
    public int getSelection() {

        return selection;
    }
    /**
     * Gets the difficulty value.
     *
     * @return The difficulty value.
     */
    public int getDifficulty() {

        return difficulty;
    }
    /**
     * Gets the data string.
     *
     * @return The data string.
     */
    public String getData() {

        return data;
    }
    /**
     * Gets the index value.
     *
     * @return The index value.
     */
    public int getIndex() {

        return index;
    }

}
