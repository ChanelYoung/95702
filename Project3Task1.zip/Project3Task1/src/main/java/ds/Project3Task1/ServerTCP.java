package ds.Project3Task1;

/**
 * This code represents a Java server that communicates with a blockchain client using JSON messages.
 * The server maintains a blockchain and responds to client requests.
 * It listens on a specific port, receives JSON requests from the client, processes them, and sends back JSON responses.
 *  */
import com.google.gson.Gson;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Timestamp;
import java.util.Scanner;


public class ServerTCP {
    private static Socket clientSocket = null;
    private static int serverPort = 7777;
    private static ResponseMessage reply_message = new ResponseMessage();
    private static RequestMessage request_message = new RequestMessage();
    private static BlockChain block_chain;
    private static Gson gson = new Gson();

    public static void main(String[] args) {
        block_chain = new BlockChain();
        Block init = new Block(block_chain.getChainSize(), block_chain.getTime(), "Genesis", 2);
        block_chain.addBlock(init);
        block_chain.computeHashesPerSecond();
        try{
            ServerSocket listenSocket = new ServerSocket(serverPort);
            System.out.println("Blockchain server running");
            //Work Cited:https://github.com/CMU-Heinz-95702/Project-2-Client-Server
            clientSocket = listenSocket.accept();
            Scanner in = new Scanner(clientSocket.getInputStream());
            PrintWriter out;
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            while (true) {
                System.out.println("----------------------------------------------------------");
                if (in.hasNextLine()) {
                    String info = in.nextLine();
                    request_message = gson.fromJson(info, RequestMessage.class);
                    if(request_message.getSelection() != 6){
                        System.out.println("We have a visitor");
                    }
                    System.out.println("THE JSON REQUEST MESSAGE IS SHOWN HERE: " + info);
                    option_activity(request_message.getSelection());
                    out.println(gson.toJson(reply_message));
                    out.flush();
                } else {
                    //Work Cited:https://github.com/CMU-Heinz-95702/Project-2-Client-Server
                    clientSocket = listenSocket.accept();
                    in = new Scanner(clientSocket.getInputStream());
                    out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                }
            }
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } finally {
            try {
                if(clientSocket != null) clientSocket.close();
            } catch (IOException e) {
            }
        }
    }


    /**
     * Performs specific actions based on the given user option, updates the reply message, and prints details.
     *
     * @param option The user's selected option for blockchain operation.
     */
    public static void option_activity(int option) {
        Timestamp launch_time;
        Timestamp finished_time;
        String response;
        if (option == 0) {
            System.out.println("User's choice: View current blockchain status");
            reply_message.setSelection(0);
            reply_message.set_chain_size(block_chain.getChainSize());
            reply_message.setChainHash(block_chain.getChainHash());
            reply_message.setTotalHashes(block_chain.getTotalExpectedHashes());
            reply_message.set_sum_of_difficulty(block_chain.getTotalDifficulty());
            reply_message.setLatestNonce(block_chain.getBlock(block_chain.getChainSize()-1).getNonce());
            reply_message.set_difficulty(block_chain.getBlock(block_chain.getChainSize()-1).getDifficulty());
            reply_message.set_hash_per_second(block_chain.getHashesPerSecond());
        } else if (option == 1) {
            System.out.println("User's choice: New Transaction(Adding a new block)");
            launch_time = block_chain.getTime();
            block_chain.addBlock(new Block(block_chain.getChainSize(), block_chain.getTime(), request_message.getData(), request_message.getDifficulty()));
            finished_time = block_chain.getTime();
            response = "Total execution time to add this block was " + (int) (finished_time.getTime() - launch_time.getTime()) +" milliseconds";
            reply_message.setSelection(1);
            reply_message.setResponse(response);
        } else if (option == 2) {
            System.out.println("User's choice: Blockchain Verification");
            launch_time = block_chain.getTime();
            String validation = block_chain.isChainValid();
            if (validation.equals("TRUE")) {
                reply_message.setVerification("TRUE");
                System.out.println("Chain verification: " + validation);
            } else {
                reply_message.setVerification(validation.split(";")[0]);
                reply_message.setErrorMessage(validation.split(";")[1]);
                System.out.println("Chain verification: " + validation.split(";")[0]);
                System.out.println(validation.split(";")[1]);
            }
            finished_time = block_chain.getTime();
            response = "Total execution time required to verify the chain was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds";
            System.out.println("Total execution time required to verify the chain was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds");
            reply_message.setResponse(response);
        } else if (option == 3) {
            System.out.println("User's choice: Blockchain Details");
            reply_message.setResponse(block_chain.toString());
        } else if (option == 4) {
            System.out.println("User's choice: Corrupt the Blockchain");
            int index = request_message.getIndex();
            String corrupt_message = request_message.getData();
            block_chain.getBlock(index).setData(corrupt_message);
            response = "Block " + index + " now holds " + corrupt_message;
            reply_message.setResponse(response);
        } else if (option == 5) {
            System.out.println("User's choice: Blockchain Repair");
            launch_time = block_chain.getTime();
            if (!block_chain.isChainValid().equals("TRUE")) {
                block_chain.repairChain();
            }
            finished_time = block_chain.getTime();
            response = "Total execution time required to repair the chain was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds";
            reply_message.setResponse(response);
        }
        System.out.println("THE JSON RESPONSE MESSAGE IS SHOWN HERE : " + gson.toJson(reply_message));
    }
}

