package ds.Project3Task1;

//Work Cited:
//https://www.andrew.cmu.edu/course/95-702/examples/javadoc/blockchaintask0/Block.html
//Self Learning:
//The Block Class
//This class represents a simple Block.
//Each Block object has an index - the position of the block on the chain. The first block (the so called Genesis block) has an index of 0.
//Each block has a timestamp - a Java Timestamp object, it holds the time of the block's creation.
//Each block has a field named data - a String holding the block's single transaction details.
//Each block has a String field named previousHash - the SHA256 hash of a block's parent. This is also called a hash pointer.
//Each block holds a nonce - a BigInteger value determined by a proof of work routine. This has to be found by the proof of work logic.
// It has to be found so that this block has a hash of the proper difficulty.
// The difficulty is specified by a small integer representing the minimum number of leading hex zeroes the hash must have.
//
//Each block has a field named difficulty -
// it is an int that specifies the minimum number of left most hex digits needed by a proper hash.
// The hash is represented in hexadecimal. If,
// for example, the difficulty is 3, the hash must have at least three leading hex 0's (or,1 and 1/2 bytes). Each hex digit represents 4 bits.(Some parts of the comments also cited from the upper website.)
// I have also taken a look at Piazza and discussed some of the purposes of functions with my classmates KW.

/**
 * This Java code defines a Block class representing an individual block in a blockchain.
 * Each block has an index, timestamp, data, previous hash, nonce, and difficulty level for mining.
 * The class provides methods for calculating the hash, performing proof-of-work, and managing block attributes.
 * */


import com.google.gson.Gson;
import java.math.BigInteger;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

public class Block {
    private int index;
    private Timestamp timestamp;
    private String data;
    private String previousHash;
    private BigInteger nonce;
    private int difficulty;


    /**
     * Constructor for the Block class.
     *
     * @param index Block index.
     * @param timestamp Timestamp of the block.
     * @param data Data to be stored in the block.
     * @param difficulty Difficulty level for mining.
     * @returns Initializes a new Block object with the provided parameters.
     */
    public Block(int index, Timestamp timestamp,String data, int difficulty) {
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
    }

    /**
     * Calculates the hash of the block.
     *
     * @returns SHA-256 hash of the block's content as a hexadecimal string.
     */
    public String calculateHash() {
        String block_to_string = "";
        block_to_string = index + timestamp.toString() + data + previousHash + nonce + difficulty;
        try {
            // Work Cited: https://github.com/CMU-Heinz-95702/Lab1-InstallationAndRaft
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(block_to_string.getBytes("UTF-8"),0,block_to_string.length());
            byte[] bytes_info;
            bytes_info = md.digest();
            return bytesToHex(bytes_info);
        }
        catch(NoSuchAlgorithmException e) {
            System.out.println("NoSuchAlgorithmException" + e);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    private String bytesToHex(byte[] bytesInfo) {
        char[] hexChars = new char[bytesInfo.length * 2];
        for (int j = 0; j < bytesInfo.length; j++) {
            int v = bytesInfo[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    /**
     * Retrieves the data of the block.
     *
     * @returns Data stored in the block.
     */
    public String getData() {

        return data;
    }

    /**
     * Retrieves the difficulty level of the block.
     *
     * @returns Difficulty level of the block.
     */
    public int getDifficulty() {

        return difficulty;
    }

    /**
     * Retrieves the index of the block.
     *
     * @returns Index of the block.
     */
    public int getIndex() {

        return index;
    }

    /**
     * Retrieves the nonce value of the block.
     *
     * @returns Nonce value of the block.
     */
    public BigInteger getNonce() {

        return this.nonce;
    }


    /**
     * Retrieves the previous hash of the block.
     *
     * @returns Previous hash of the block.
     */
    public String getPreviousHash() {

        return previousHash;
    }


    /**
     * Retrieves the timestamp of the block.
     *
     * @returns Timestamp of the block.
     */
    public Timestamp getTimestamp() {

        return timestamp;
    }

    public static void main(String[] args) {
    }

    /**
     * Performs a proof-of-work to find a valid hash for the block.
     *
     * @returns Valid hash meeting the required difficulty level.
     */
    public String proofOfWork() {
        //Work Cited:https://docs.oracle.com/javase%2F7%2Fdocs%2Fapi%2F%2F/java/math/BigInteger.html
        nonce = BigInteger.ZERO;
        String zeros = "0".repeat(difficulty);

        while (true) {
            String hash = calculateHash();
            if (hash.startsWith(zeros)) {
                return hash;
            } else {
                nonce =  this.nonce.add(BigInteger.ONE);
            }
        }
    }

    /**
     * Sets the data of the block.
     *
     * @param data New data to be set in the block.
     * @returns No explicit return value.
     */
    public void setData(String data) {

        this.data = data;
    }

    /**
     * Sets the difficulty level of the block.
     *
     * @param difficulty New difficulty level to be set.
     * @returns No explicit return value.
     */
    public void setDifficulty(int difficulty) {

        this.difficulty = difficulty;
    }

    /**
     * Sets the index of the block.
     *
     * @param index New index to be set.
     * @returns No explicit return value.
     */
    public void setIndex(int index) {

        this.index = index;
    }

    /**
     * Sets the previous hash of the block.
     *
     * @param previousHash New previous hash to be set.
     * @returns No explicit return value.
     */
    public void setPreviousHash(String previousHash) {

        this.previousHash = previousHash;
    }

    /**
     * Sets the timestamp of the block.
     *
     * @param timestamp New timestamp to be set.
     * @returns No explicit return value.
     */
    public void setTimestamp(Timestamp timestamp) {

        this.timestamp = timestamp;
    }

    /**
     * Creates a JSON representation of the block.
     *
     * @returns JSON representation of the block.
     */
    public String toString() {
        Block block_helper = new Block (index, timestamp, data, difficulty);
        block_helper.nonce = nonce;
        block_helper.setPreviousHash(previousHash);
        Gson gson = new Gson();
        return gson.toJson(block_helper);
    }

}