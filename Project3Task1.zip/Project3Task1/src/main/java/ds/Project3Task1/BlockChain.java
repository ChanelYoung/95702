package ds.Project3Task1;
import com.google.gson.Gson;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This Java code defines a BlockChain class for a simple blockchain. It offers methods for adding blocks, verifying integrity, and repair.
 * The main method serves as a command-line interface for user interaction, enabling actions like adding transactions and monitoring blockchain statistics.
 * */

//Work Cited:https://www.andrew.cmu.edu/course/95-702/examples/javadoc/blockchaintask0/BlockChain.html
//Self Learning:
// This class represents a simple BlockChain.(Some parts of the comments also cited from the upper website.)
// I have also taken a look at Piazza and discussed some of the purposes of functions with my classmates KW.

public class BlockChain {
    //This BlockChain has exactly three instance members - an ArrayList to hold Blocks and a chain hash to hold a SHA256 hash of the most recently added Block. It also maintains an instance variable holding the approximate number of hashes per second on this computer. This constructor creates an empty ArrayList for Block storage.
    // This constructor sets the chain hash to the empty string and sets hashes per second to 0.
    private final ArrayList<Block> block_chain;
    private String chainHash;
    private int hashes_per_second;


    public BlockChain() {
        this.block_chain = new ArrayList<>();
        this.chainHash = "";
    }


    /**
     * Get the chain hash.
     *
     * @return The chain hash as a string.
     */
    public String getChainHash() {

        return chainHash;
    }

    /**
     * Get the current timestamp.
     *
     * @return The current timestamp as a Timestamp object.
     */
    public Timestamp getTime() {
        //Work Cited: https://www.tutorialspoint.com/java/lang/system_currenttimemillis.htm
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * Get the last block in the block chain.
     *
     * @return The last block as a Block object.
     */
    public Block getLastBlock() {

        return block_chain.get(block_chain.size()-1);
    }

    /**
     * Get the size of the block chain.
     *
     * @return The size of the block chain as an integer.
     */
    public int getChainSize() {

        return block_chain.size();
    }

    /**
     * Computes the number of hashes per second and sets the instance variable hashesPerSecond.
     */
    public void computeHashesPerSecond() {
        //This method computes exactly 2 million hashes and times how long that process takes. So, hashes per second is approximated as (2 million / number of seconds). It is run on start up and sets the instance variable hashesPerSecond.
        // It uses a simple string - "00000000" to hash.
        Timestamp launch_time = getTime();
        int num = 0;
        for (int i = 0; i< 2000000; i++){
            // Work Cited: https://github.com/CMU-Heinz-95702/Lab1-InstallationAndRaft
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] bytes_info;
                md.update("00000000".getBytes("UTF-8"), 0, "00000000".length());
                bytes_info = md.digest();
                char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
                char[] hexChars = new char[bytes_info.length * 2];
                for (int j = 0; j < bytes_info.length; j++) {
                    int v = bytes_info[j] & 0xFF;
                    hexChars[j * 2] = HEX_ARRAY[v >>> 4];
                    hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
                }
            } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            }
        }
        Timestamp end_time = getTime();
        //Work Cited:https://docs.oracle.com/javase/8/docs/api/java/sql/Timestamp.html
        hashes_per_second = (int) (2000000 / (end_time.getTime() - launch_time.getTime())*1000.0);
    }

    /**
     * Get the number of hashes per second.
     *
     * @return The number of hashes per second as an integer.
     */
    public int getHashesPerSecond() {

        return hashes_per_second;
    }

    /**
     * Add a new block to the block chain.
     *
     * @param newBlock The new block to be added.
     */
    public void addBlock(Block newBlock) {
        //Within the block x, there is a previous hash field.
        newBlock.setPreviousHash(chainHash);
        block_chain.add(newBlock);
        //It is important to also maintain a hash of the most recently added block in a chain hash.
        chainHash = newBlock.proofOfWork();
    }


    /**
     * Generate a JSON representation of the entire block chain.
     *
     * @return A JSON representation of the block chain as a string.
     */
    public String toString() {
        BlockChain blockchain_to_json = new BlockChain();
        for(int i = 0; i < getChainSize(); i++) {
            blockchain_to_json.block_chain.add(getBlock(i));
        }
        blockchain_to_json.hashes_per_second = getHashesPerSecond();
        blockchain_to_json.chainHash = getChainHash();
        Gson gson = new Gson();
        return gson.toJson(blockchain_to_json);
    }

    /**
     * Get a specific block from the block chain.
     *
     * @param i The index of the block to retrieve.
     * @return The block at the specified index as a Block object.
     */
    public Block getBlock(int i ) {

        return block_chain.get(i);
    }

    /**
     * Calculate the total difficulty of all blocks in the chain.
     *
     * @return The total difficulty as an integer.
     */
    public int getTotalDifficulty() {
        int sum_of_difficulty = 0;
        for (int i = 0; i < block_chain.size(); i++) {
            sum_of_difficulty += block_chain.get(i).getDifficulty();
        }
        return sum_of_difficulty;
    }

    /**
     * Calculate the total expected hashes required for the entire chain.
     *
     * @return The total expected hashes as a double.
     */
    public double getTotalExpectedHashes() {
        double sum_of_TotalExpectedHashes = 0;
        for(Block helper: block_chain) {
            sum_of_TotalExpectedHashes += Math.pow("0123456789ABCDEF".length(), helper.getDifficulty());
        }
        return sum_of_TotalExpectedHashes;
    }

    /**
     * Check if the chain is valid and has not been tampered with.
     *
     * @return "True" if the chain is valid, "False" if not.
     */
    public String isChainValid() {
        Block current_block;
        String hash;
        String previous_hash = "";
        for (int i = 0; i < this.block_chain.size(); i++){
            current_block = this.block_chain.get(i);
            //In the case of the first block,
            // the initial value of preHash is an empty string "",
            // not an actual hash value.
            // Therefore, even if there is no previousHash in the first block,
            // the loop does not throw an error
            // because the function sets an empty string as the initial value,
            // which matches the Genesis block.
            if (!current_block.getPreviousHash().equals(previous_hash)){
//                System.out.printf("Improper hash on node %d Does not match with %s\n",i, previous_hash);
                String error_message = "Improper hash on node " + i + " Does not match with " + previous_hash;
                return "FALSE" +";" + error_message;
            }
            String begin_of_zero_amount = "0".repeat(current_block.getDifficulty());
            hash = current_block.calculateHash();
            if (!hash.startsWith(begin_of_zero_amount)){
//                System.out.printf("Improper hash on node %d Does not begin with %s\n",i,begin_of_zero_amount);
                String error_message = "Improper hash on node " + i +  " Does not begin with " + begin_of_zero_amount;
                return "FALSE" +";" + error_message;
            }
            previous_hash = hash;
        }
        if (!chainHash.equals(previous_hash)){
            return "FALSE" +";" + "Improper hash";
        }
        return "TRUE";

    }

    /**
     * Repair the chain by updating previous hashes and chain hash.
     */
    public void repairChain() {
        Block current_block;
        String previous_hash = "";
        for (int i = 0; i < this.block_chain.size(); i++){
            current_block = this.block_chain.get(i);
            current_block.setPreviousHash(previous_hash);
            previous_hash = current_block.proofOfWork();
        }
        this.chainHash = previous_hash;
    }


    public static void main(java.lang.String[] args) {
        //This routine acts as a test driver for your Blockchain.
        // It will begin by creating a BlockChain object and then adding the Genesis block to the chain.
        // The Genesis block will be created with an empty string as the pervious hash and a difficulty of 2.
        BlockChain main_block_chain = new BlockChain();
        main_block_chain.computeHashesPerSecond();
        Block genesisBlock = new Block(0, main_block_chain.getTime(), "Genesis", 2);
        main_block_chain.addBlock(genesisBlock);
        //main_block_chain.computeHashesPerSecond();
        Scanner scanner = new Scanner(System.in);
        Timestamp launch_time;
        Timestamp finished_time;
        while(true){
            System.out.println("0. View basic blockchain status.\n" +
                    "1. Add a transaction to the blockchain.\n" +
                    "2. Verify the blockchain.\n" +
                    "3. View the blockchain.\n" +
                    "4. Corrupt the chain.\n" +
                    "5. Hide the corruption by repairing the chain.\n" +
                    "6. Exit.\n");
            int user_choice = scanner.nextInt();

            if (user_choice == 0) {
                //If the user selects option 0, the program will display:
                // The number of blocks on the chain Difficulty of most recent block
                // The total difficulty for all blocks
                // Approximate hashes per second on this machine.
                // Expected total hashes required for the whole chain.
                // The computed nonce for most recent block. The chain hash (hash of the most recent block).
                System.out.println("Current size of chain: " + main_block_chain.getChainSize());
                System.out.println("Total difficulty for all blocks: " + main_block_chain.getLastBlock().getDifficulty());
                System.out.println("Total difficulty for all blocks: " + main_block_chain.getTotalDifficulty());
                System.out.println("Approximate hashes per second on this machine: " + main_block_chain.getHashesPerSecond());
                System.out.println("Expected total hashes required for the whole chain: " + main_block_chain.getTotalExpectedHashes());
                System.out.println("Nonce for most recent block: " + main_block_chain.getLastBlock().getNonce());
                System.out.println("Chain hash:" + main_block_chain.getChainHash());
            } else if (user_choice == 1) {
                //If the user selects option 1, the program will prompt for and then read the difficulty level for this block.
                // It will then prompt for and then read a line of data from the user (representing a transaction).
                // The program will then add a block containing that transaction to the block chain.
                // The program will display the time it took to add this block.
                // Note: The first block added after Genesis has index 1. The second has 2 and so on. The Genesis block is at position 0.
                System.out.println("Enter difficulty > 0");
                int difficulty = scanner.nextInt();
                System.out.println("Enter transaction");
                scanner.nextLine();
                String data_for_new_block = scanner.nextLine();
                Block helper_block = new Block(main_block_chain.getChainSize(), main_block_chain.getTime(), data_for_new_block, difficulty);
                launch_time = main_block_chain.getTime();
                main_block_chain.addBlock(helper_block);
                finished_time = main_block_chain.getTime();
                System.out.println("Total execution time to add this block was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds");
            } else if (user_choice == 2) {
                //If the user selects option 2, then call the isChainValid method and display the results.
                // It is important to note that this method will execute fast.
                // Blockchains are easy to validate but time consuming to modify.
                // Your program needs to display the number of milliseconds it took for validate to run.
                launch_time = main_block_chain.getTime();
                String answer = main_block_chain.isChainValid();
                if(answer.equals("TRUE")){
                    System.out.println("Chain verification: " + answer);
                }
                else{
                    String[] result = answer.split(";");
                    System.out.println("Chain verification: " + result[0]);
                    System.out.println(result[1]);}
                finished_time = main_block_chain.getTime();
                System.out.println("Total execution time required to verify the chain was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds");
            } else if (user_choice == 3) {
                //If the user selects option 3, display the entire Blockchain contents as a correctly formed JSON document. See www.json.org.
                System.out.println("View the Blockchain");
                System.out.println(main_block_chain.toString());
            } else if (user_choice == 4) {
                //If the user selects option 4, she wants to corrupt the chain.
                // Ask her for the block index (0..size-1) and ask her for the new data that will be placed in the block.
                System.out.println("corrupt the Blockchain");
                System.out.println("Enter block ID of block to corrupt: ");
                int blockId = scanner.nextInt();
                System.out.println("Enter new data for block " + blockId);
                scanner.nextLine();
                String new_data = scanner.nextLine();
                Block corrupt_block = main_block_chain.block_chain.get(blockId);
                corrupt_block.setData(new_data);
                System.out.printf("Block %d now holds %s\n", blockId, new_data);
            } else if (user_choice == 5) {
                //If the user selects 5, she wants to repair the chain.
                // That is, she wants to recompute the proof of work for each node that has become invalid - due perhaps, to an earlier selection of option 4.
                // The program begins at the Genesis block and checks each block in turn.
                // If any block is found to be invalid, it executes repair logic.
                launch_time = main_block_chain.getTime();
                main_block_chain.repairChain();
                finished_time = main_block_chain.getTime();
                System.out.println("Total execution time required to repair the chain was " + (int) (finished_time.getTime() - launch_time.getTime()) + " milliseconds");
            } else if (user_choice == 6) {
                break;
            } else {
                System.out.println("Invalid option.");
            }

        }
    }
}
