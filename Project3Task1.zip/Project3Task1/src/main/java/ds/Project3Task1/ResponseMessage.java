package ds.Project3Task1;

import java.math.BigInteger;

/**
 * This is a response message class used to deal with the production of response message
 * */

//For this question, I have discussed with PW, XY for som function clarifications.
// Work Cited: Piazza

public class ResponseMessage {
    private int size;
    private int difficulty;
    private int sum_of_difficulty;
    private Double totalHashes;
    private String verify_result;
    private String errorMessage;
    private BigInteger nonce;
    private String chainHash;
    private String response;
    private int hash_per_second;

    /**
     * Get the hash per second.
     *
     */
    public int get_hash_per_second() {
        return hash_per_second;
    }

    /**
     * Set the hash per second.
     *
     */
    public void set_hash_per_second(int second) {
        this.hash_per_second = second;
    }

    public ResponseMessage() {
    }

    /**
     * Set the selection value.
     *
     * @param selection The selection value to set.
     */
    public void setSelection(int selection) {
    }
    /**
     * Get the size value.
     *
     * @return The size value.
     */
    public int get_chain_size() {

        return size;
    }
    /**
     * Set the size value.
     *
     * @param size The size value to set.
     */
    public void set_chain_size(int size) {

        this.size = size;
    }
    /**
     * Get the difficulty value.
     *
     * @return The difficulty value.
     */
    public int get_difficulty() {

        return difficulty;
    }
    /**
     * Set the difficulty value.
     *
     * @param level The diff value to set.
     */
    public void set_difficulty(int level) {
        this.difficulty = level;
    }
    /**
     * Get the totalDiff value.
     *
     * @return The totalDiff value.
     */
    public int get_sum_of_difficulty() {

        return sum_of_difficulty;
    }
    /**
     * Set the totalDiff value.
     *
     * @param total The totalDiff value to set.
     */
    public void set_sum_of_difficulty(int total) {
        this.sum_of_difficulty = total;
    }

    /**
     * Get the totalHashes value.
     *
     * @return The totalHashes value.
     */
    public Double getTotalHashes() {

        return totalHashes;
    }
    /**
     * Set the totalHashes value.
     *
     * @param totalHashes The totalHashes value to set.
     */
    public void setTotalHashes(Double totalHashes) {

        this.totalHashes = totalHashes;
    }
    /**
     * Get the latest Nonce value.
     *
     * @return The latest Nonce value.
     */
    public BigInteger getLatestNonce() {

        return nonce;
    }
    /**
     * Set the latest Nonce value.
     *
     * @param Nonce The latest Nonce value to set.
     */
    public void setLatestNonce(BigInteger Nonce) {

        this.nonce = Nonce;
    }
    /**
     * Get the chainHash value.
     *
     * @return The chainHash value.
     */
    public String getChainHash() {

        return chainHash;
    }
    /**
     * Set the chainHash value.
     *
     * @param chainHash The chainHash value to set.
     */
    public void setChainHash(String chainHash) {

        this.chainHash = chainHash;
    }
    /**
     * Get the response string.
     *
     * @return The response string.
     */
    public String getResponse() {

        return response;
    }
    /**
     * Set the response string.
     *
     * @param response The response string to set.
     */
    public void setResponse(String response) {

        this.response = response;
    }
    /**
     * Get the verification string.
     *
     * @return The verification string.
     */
    public String getVerification() {

        return verify_result;
    }
    /**
     * Set the verification string.
     *
     * @param verification The verification string to set.
     */
    public void setVerification(String verification) {

        this.verify_result = verification;
    }

    /**
     * Get the error message for the second option: blockchain verification.
     *
     */
    public String getErrorMessage() {

        return errorMessage;
    }
    /**
     * Set the error message for the second option: blockchain verification.
     *
     */
    public void setErrorMessage(String errorMessage) {

        this.errorMessage = errorMessage;
    }
}
