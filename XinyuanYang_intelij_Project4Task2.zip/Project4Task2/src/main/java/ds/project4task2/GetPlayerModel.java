package ds.project4task2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

/**
 * This class GetPlayerModel retrieves and processes basketball player information
 * from an external API, stores the data in a MongoDB database, and calculates
 * statistics based on the stored information for dashboard use.
 *
 * @author Xinyuan Yang
 * @e-mail xy3@andrew.cmu.edu
 * Great thanks to discussion with classmate Kathy W, and piazza, our project1&2, lab3
 */

public class GetPlayerModel {

    //Work Cited:https://www.mongodb.com/docs/atlas/tutorial/connect-to-your-cluster/
    static ConnectionString connectionString = new ConnectionString("mongodb+srv://chacha:awsdcha99@cluster0.6ai042i.mongodb.net/?retryWrites=true&w=majority");
    static MongoClientSettings settings = MongoClientSettings.builder()
            .applyConnectionString(connectionString)
            .serverApi(ServerApi.builder()
                    .version(ServerApiVersion.V1)
                    .build())
            .build();

    static ArrayList<String> mongodb_result;
    static Map<String, Integer> keyword_frequency = new HashMap<>();
    static double average_score = 0.0;
    static Integer searchAmount = 0;

    static PriorityQueue<AbstractMap.SimpleEntry<String, Integer>> currentSaverForTheToppestFirstName = new PriorityQueue<>(
            (entry1, entry2) -> entry1.getValue() - entry2.getValue()
    );

    /**
     * Generate player information by making an API call, extracting relevant data,
     * and storing it in a MongoDB database.
     *
     * @param first_name The first name of the basketball player.
     * @return The JSON object containing information about the selected player.
     * @throws ParseException If there's an error parsing the JSON response.
     */
    public static JSONObject generateInfo(String first_name) throws ParseException {
        String address = "https://basketapi1.p.rapidapi.com/api/basketball/search/" + first_name;
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
        String output = api_fetch(address);
        JSONObject output_object = (JSONObject) JSONValue.parse(output);
        JSONArray results = (JSONArray) output_object.get("results");
        Random random = new Random();
        int randomNumber = random.nextInt((results.size() - 1 - 0) + 1) + 0;
        JSONObject currentPlayer = null;
        if (results != null) {
            currentPlayer = (JSONObject) results.get(randomNumber);
            JSONObject entity = (JSONObject) currentPlayer.get("entity");
            String full_name = (String) entity.get("name");
            String position = (String) entity.get("position");
            String teamSlug = "no-team";
            String nameCode = "N/A";
            Double score = 0.0;
            if (full_name.toLowerCase().contains(first_name.toLowerCase())) {
                if (entity.get("team") != null) {
                    JSONObject team = (JSONObject) entity.get("team");
                    teamSlug = (String) team.get("slug");
                    nameCode = (String) team.get("nameCode");
                    score = (Double) currentPlayer.get("score");
                }
            }
            String time = sdf.format(new Date(System.currentTimeMillis()));
            connect();
            pushToMongoDB(first_name, full_name, position, teamSlug, nameCode, score, time);
        }
        return currentPlayer;
    }


    /**
     * Establish a connection to the MongoDB database and retrieves data from
     * the "NBA" collection; then invoke the statistics method to perform
     * statistical analysis on the retrieved data.
     */
    //Work Cited:https://www.mongodb.com/docs/atlas/tutorial/insert-data-into-your-cluster/
    //Work Cited:https://www.mongodb.com/docs/drivers/java/sync/v4.3/usage-examples/findOne/
    static public void connect() {
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("Project4");
        MongoCollection<Document> col = database.getCollection("NBA");
        FindIterable<Document> iterDoc = col.find();
        mongodb_result = new ArrayList<>();
        MongoCursor<Document> cursor = iterDoc.iterator();
        statistics(cursor);
    }


    /**
     * Performs statistical analysis on MongoDB documents retrieved using the provided cursor.
     * Calculates the total count, total score, and keyword frequency. Updates the global
     * data structures, such as keyword_frequency, mongodb_result, currentSaverForTheToppestFirstName,
     * average_score, and searchAmount.
     *
     * @param cursor The cursor containing MongoDB documents for analysis.
     */
    static public void statistics(MongoCursor<Document> cursor) {
        int totalCount = 0;
        double totalScore = 0;
        while (cursor.hasNext()) {
            Document document = cursor.next();
            int get1 = keyword_frequency.getOrDefault((String) document.get("first_name"), 0);
            keyword_frequency.put((String) document.get("first_name"), get1 + 1);

            if (document.containsKey("score")) {
                totalCount++;
                totalScore += Double.parseDouble(document.get("score").toString());
            }
            String s = document.getString("name") + document.get("first_name") + ", " + document.getString("full_name") + ", " + document.getString("position") + ", " +
                    document.getString("teamSlug") + ", " + document.getString("nameCode") + ", " + document.get("score") + ", " + document.get("time");
            mongodb_result.add(s);
        }
        for (Map.Entry<String, Integer> entry : keyword_frequency.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
            currentSaverForTheToppestFirstName.add(new AbstractMap.SimpleEntry<>(entry.getKey(), entry.getValue()));
            if (currentSaverForTheToppestFirstName.size() > 1) {
                currentSaverForTheToppestFirstName.poll();
            }
        }
        if (totalCount > 0) {
            average_score = totalScore / totalCount;
        }
        searchAmount = totalCount;
    }


    /**
     * Fetches data from an external API using the provided URL string.
     *
     * @param urlString The URL string for the API endpoint.
     * @return The response data from the API.
     */
    //Work Cited:https://www.tabnine.com/code/java/methods/java.net.URL/openConnection
    static private String api_fetch(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            String X_RapidAPI_Key = "7f942614ecmshde09332679c2d72p15cf71jsnb41d4c83c511";
            String X_RapidAPI_Host = "basketapi1.p.rapidapi.com";
            connection.setRequestProperty("X-RapidAPI-Key", X_RapidAPI_Key);
            connection.setRequestProperty("X-RapidAPI-Host", X_RapidAPI_Host);
            connection.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            while ((str = in.readLine()) != null) {
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("exception");
        }
        return response;
    }



    /**
     * Inserts player information into the MongoDB database in the "NBA" collection.
     *
     * @param first_name The first name of the basketball player.
     * @param full_name The full name of the basketball player.
     * @param position The position of the basketball player.
     * @param teamSlug The team slug of the basketball player.
     * @param nameCode The name code of the basketball player.
     * @param score The score of the basketball player.
     * @param time The timestamp of when the information was stored.
     */
    //Work Cited:https://www.mongodb.com/docs/atlas/tutorial/insert-data-into-your-cluster/
    static private void pushToMongoDB(String first_name, String full_name, String position, String teamSlug, String nameCode, Double score, String time) {
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("Project4");
        MongoCollection col = database.getCollection("NBA");
        Document doc = new Document("name", "AndroidUser: ");
        doc.append("first_name", first_name);
        doc.append("full_name", full_name);
        doc.append("position", position);
        doc.append("teamSlug", teamSlug);
        doc.append("nameCode", nameCode);
        doc.append("score", String.valueOf(score));
        doc.append("time", time);
        col.insertOne(doc);
    }

}
