package ds.project4task2;
import java.io.*;
import java.util.ArrayList;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

/**
 * GetPlayerServlet is a servlet class that handles HTTP requests related to player information retrieval
 * and dashboard statistics in a Java web application. It interacts with the GetPlayerModel class to
 * fetch data from external APIs, store it in a MongoDB database, and perform statistical analysis.
 * @author Xinyuan Yang
 * @e-mail xy3@andrew.cmu.edu
 * Great thanks to discussion with classmate Kathy W, and piazza, our project1&2, lab3
 * **/

@WebServlet(name = "GetPlayerServlet", urlPatterns = {"/GetPlayer", "/getDashBoard"})
public class GetPlayerServlet extends HttpServlet {

    @Override
    public void init() {
    }
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String path = request.getServletPath();
        String nextView = "";
        //Invalid server-side input
        if (path.contains("GetPlayer")) {
            if (request.getParameter("first_name") == null) {
                System.out.println("Error in request parameters.");
            }
            String first_name = request.getParameter("first_name");
            if (!first_name.matches("[a-zA-Z]+")){
                System.out.println("Invalid mobile app input");
            }
            System.out.println("first_name: " + first_name);
            JSONObject result = null;
            try {
                result = GetPlayerModel.generateInfo(first_name);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            if (result == null) {
                nextView = "index.jsp";
            } else {
                request.setAttribute("result", result);
                nextView = "result.jsp";
            }
        } else if (path.contains("getDashBoard")) {
            GetPlayerModel.connect();
            request.setAttribute("result", GetPlayerModel.mongodb_result);
            System.out.println("mongodb_result: "+GetPlayerModel.mongodb_result);
            ArrayList<String> main_first_name = new ArrayList<>();
            Double average_score = 0.0;
            Integer searchAmount = 0;
            request.setAttribute("main_first_name", main_first_name);
            for (int i = 0; i < 1; i++) {
                if (!GetPlayerModel.currentSaverForTheToppestFirstName.isEmpty()) {
                    String key = GetPlayerModel.currentSaverForTheToppestFirstName.poll().getKey();
                    main_first_name.add(key);
                }
            }
            average_score = GetPlayerModel.average_score;
            request.setAttribute("average_score", average_score);

            searchAmount = GetPlayerModel.searchAmount;
            request.setAttribute("searchAmount", searchAmount);
            nextView = "dashboard.jsp";
        }
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
    public void destroy() {
    }
}
