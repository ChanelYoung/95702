package edu.heinz.ds.androidinterestingplayer;
import android.app.Activity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * The GetPlayer class facilitates the retrieval of player information using a third-party API in an Android app.
 * It includes a nested BackgroundTask class that manages asynchronous execution.
 *
 * @author Xinyuan Yang
 * @e-mail xy3@andrew.cmu.edu
 * Great thanks to discussion with classmate Kathy W, and piazza, our project1&2, lab3, lab8-AndroidInterestingPicture
 * Work Cited: https://www.tutlane.com/tutorial/android/android-checkbox-with-examples
 **/
public class GetPlayer {
    InterestingPlayer ip = null;
    String searchTerm = null;
    String Player = null;


    public void search(String searchTerm, Activity activity, InterestingPlayer ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        new BackgroundTask(activity).execute();
    }


    private class BackgroundTask {

        private Activity activity;

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }
        /**
         * Initiate the execution of a background task by creating a new thread that runs the doInBackground method.
         * After the background task completes, the onPostExecute method is executed on the UI thread using
         * activity.runOnUiThread.
         */
        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    doInBackground();
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }
        /**
         * Initiate the execution of a background task by calling the startBackground method.
         */
        private void execute(){
            startBackground();
        }
        /**
         * Perform background execution by calling the search method to retrieve player information based on
         * the provided search term.
         *
         */
        private void doInBackground() {
            Player = search(searchTerm);
        }
        /**
         * Handle the post-execution phase by calling the PlayerReady method of the associated InterestingPlayer
         * instance (ip) to update the UI with the retrieved player information.
         *
         */
        public void onPostExecute() {
            ip.PlayerReady(Player);
        }

        /**
         * Perform a search for player information based on the provided search term using a third-party API.
         * Update the UI with the retrieved player information or appropriate error messages.
         *
         * @param searchTerm The term used to search for player information.
         *
         * @return A formatted string containing player information (if found), or appropriate error messages.
         */
        private String search(String searchTerm) {
            System.out.println("search");
            String requestString = "https://studious-happiness-x4qxqgqjv4qhp97r-8080.app.github.dev/GetPlayer";
            //local-testing
//            String requestString ="http://192.168.1.157:8080/Project4Task2-1.0-SNAPSHOT/GetPlayer";
            String response = "";
            int status;

            //Invalid mobile app input
            if (!searchTerm.matches("[a-zA-Z]+")){
                System.out.println("Invalid mobile app input");
                return "Invalid mobile app input";
            }else {
                requestString += "?first_name=";
                requestString += searchTerm;
                System.out.println("Test: "+requestString);
            }

            try {
                URL url = new URL(requestString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                status = connection.getResponseCode();
                System.out.println("status"+status);
                if (status != 200) {
                    if(status == 500){
                        System.out.println("500: no data fetched:).");
                        return String.valueOf(status);
                    }
                    if(status == 404){
                        System.out.println("404: Error:).");
                        return String.valueOf(status);
                    }
                }
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;
                while ((str = in.readLine()) != null) {
                    response += str;
                }

                in.close();
                //Deal with invalid data(some attributes missing) through N/A initialized
                System.out.println("response: "+response);
                JSONObject jsonObject = new JSONObject(response);
                System.out.println("JSONObject: "+jsonObject);

                double score = jsonObject.optDouble("score", Double.NaN);
                System.out.println("score: " + (Double.isNaN(score) ? "not applicable" : score));

                String name = jsonObject.optJSONObject("entity").optString("name", "not applicable");
                System.out.println("name: " + name);

                String position = jsonObject.optJSONObject("entity").optString("position", "not applicable");
                System.out.println("position: " + position);

                String nameCode = "not applicable";
                String slug = "not applicable";
                JSONObject entity = jsonObject.optJSONObject("entity");
                if (entity != null) {
                    JSONObject team = entity.optJSONObject("team");
                    if (team != null) {
                        nameCode = team.optString("nameCode", "not applicable");
                        slug = team.optString("slug","not applicable");
                    }
                }
                String resultString = "Score: " + score + "\n" +
                        "Name: " + name +  "\n" +
                        "Position: " + position + "\n" +
                        "Team: " + nameCode +"\n" +
                        "Slug: " + slug;

                connection.disconnect();
                return resultString;
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Third-party API unavailable");
                return null;
            }
        }

    }
}