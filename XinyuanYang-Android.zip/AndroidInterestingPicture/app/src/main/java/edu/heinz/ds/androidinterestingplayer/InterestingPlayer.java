package edu.heinz.ds.androidinterestingplayer;
/**
 * InterestingPlayer is an Android app activity that allows users to input a first_name, and help
 * search a corresponding player related with this first_name.
 * Each time, the App will random select a player to present based on data from
 * a third-party API.
 * There is then a check-box waiting to show whether user are satisfied, if user click,
 * a sentence "Bravo" will appear and a smile picture will also appear.
 * If user takes away the click,
 * the sentence and smile picture will be invisible.
 * @author Xinyuan Yang
 * @e-mail xy3@andrew.cmu.edu
 * Great thanks to discussion with classmate Kathy W, and piazza, our project1&2, lab3, lab8-AndroidInterestingPicture
 * Work Cited: https://www.tutlane.com/tutorial/android/android-checkbox-with-examples
 **/
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class InterestingPlayer extends AppCompatActivity {
    InterestingPlayer me = this;


    /**
     * Initialize the activity when it is first created: setting up the user interface,
     * event listeners for button and checkbox clicks.
     *
     * @param savedInstanceState The saved state of the activity, which contains data previously supplied to
     *                            the activity, if applicable.
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("Android App starts.");
        final InterestingPlayer ma = this;
        Button submitButton = findViewById(R.id.submit);
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View viewParam) {
                String searchTerm = ((EditText) findViewById(R.id.searchTerm)).getText().toString();
                GetPlayer gp = new GetPlayer();
                gp.search(searchTerm, me, ma);
            }
        });

        CheckBox judge = findViewById(R.id.judge);
        judge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCheckboxClicked(view);
            }
        });
    }
    /**
     * Handle the response from a player search operation and updates the UI with the retrieved player information
     * or appropriate error messages based on the response.
     *
     * @param Player The result of the player search operation, represented as a String.
     *
     */
    public void PlayerReady(String Player) {
        TextView PlayerView = findViewById(R.id.result);
        TextView searchView = findViewById(R.id.searchTerm);

        //Third-party API invalid data
        if(Player.equals("500")){PlayerView.setText("No players founded.");}
        else if(Player.equals("404")){
            PlayerView.setText("404 Page Not Found");
        }
        else{
        if (Player != null) {
            PlayerView.setText(Player);
        } else {
            //Mobile app network failure, unable to reach server
            String error = "Mobile app network failure, unable to reach server";
            PlayerView.setText(error);
            System.out.println("Connection Error");
        }
        searchView.setText("");
    }}
    /**
     * Handle the state change of a checkbox and updates the UI accordingly. If the checkbox is checked,
     * it displays an interesting picture, sets a satisfaction message, and makes the picture visible. If
     * the checkbox is unchecked, it hides the interesting picture and resets the satisfaction message.
     *
     * @param view The checkbox view that was clicked.
     *
     */
    public void onCheckboxClicked(View view) {
        boolean check = ((CheckBox) view).isChecked();
        if (check) {
            TextView SatisfyView = findViewById(R.id.satisfy);
            System.out.println("You got it!");
            ImageView InteresingPicture = findViewById(R.id.interestingPicture);
            Bitmap picture = BitmapFactory.decodeResource(getResources(), R.drawable.smile);

            InteresingPicture.setImageBitmap(picture);
            InteresingPicture.setVisibility(View.VISIBLE);
            SatisfyView.setText("Bravo!");
        }
        else{
            //Picture saved in the drawable category, downloaded from google pictures.
            TextView SatisfyView = findViewById(R.id.satisfy);
            SatisfyView.setText("");
            ImageView InteresingPicture = findViewById(R.id.interestingPicture);
            Bitmap picture = BitmapFactory.decodeResource(getResources(), R.drawable.smile);
            InteresingPicture.setImageBitmap(picture);
            System.out.println("Not satisfy");
            InteresingPicture.setVisibility(View.INVISIBLE);
        }
    }
}
